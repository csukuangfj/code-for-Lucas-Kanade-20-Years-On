double f(int n, double (*A)[n])
{
	double r = 0;
	for (int i = 0; i < n; i++)
	for (int j = 0; j < n; j++)
	return A[1][1];
}
