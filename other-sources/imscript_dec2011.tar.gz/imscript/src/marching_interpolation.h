float marchi(float a, float b, float c, float d, float x, float y);
